#include<iostream>
#include <algorithm>
#include <string>
#include "geoQuiz.h"

