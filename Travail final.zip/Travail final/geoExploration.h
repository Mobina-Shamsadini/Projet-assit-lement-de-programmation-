#pragma once
#include "geoQuiz.h"
#include <string>

double convertisseur(int montant = 100, std::string devise = "AED");
void geoExploration(Profil test);
void voyager(std::string* voyages, int nbEtapes);
